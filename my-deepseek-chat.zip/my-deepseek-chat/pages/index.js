import { useState } from 'react';

export default function Home() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const newMessages = [...messages, { role: 'user', content: input }];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      // 重点：请求我们自己的后端路由，而不是直连 DeepSeek
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: newMessages })
      });
      const data = await res.json();
      
      if (data.choices && data.choices[0]) {
        setMessages([...newMessages, data.choices[0].message]);
      }
    } catch (e) {
      alert('出错啦，请检查配置');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '50px auto', padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>我的 DeepSeek AI 助手</h2>
      <div style={{ border: '1px solid #ccc', height: '400px', overflowY: 'scroll', padding: '10px', marginBottom: '10px', borderRadius: '8px' }}>
        {messages.map((msg, i) => (
          <div key={i} style={{ margin: '10px 0', textAlign: msg.role === 'user' ? 'right' : 'left' }}>
            <span style={{ background: msg.role === 'user' ? '#0070f3' : '#eaeaea', color: msg.role === 'user' ? 'white' : 'black', padding: '8px 12px', borderRadius: '12px', display: 'inline-block' }}>
              {msg.content}
            </span>
          </div>
        ))}
        {loading && <p style={{ color: '#888' }}>AI 正在思考中...</p>}
      </div>
      <div style={{ display: 'flex', gap: '10px' }}>
        <input style={{ flex: 1, padding: '10px', borderRadius: '4px', border: '1px solid #ccc' }} value={input} onChange={(e) => setInput(e.target.value)} placeholder="输入消息..." onKeyDown={(e) => e.key === 'Enter' && handleSend()} />
        <button style={{ padding: '10px 20px', background: '#0070f3', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }} onClick={handleSend}>发送</button>
      </div>
    </div>
  );
}
